package com.perfulandia.perfulandia_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PerfulandiaServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PerfulandiaServiceApplication.class, args);
	}

}
