package com.perfulandia.perfulandia_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PerfulandiaServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
